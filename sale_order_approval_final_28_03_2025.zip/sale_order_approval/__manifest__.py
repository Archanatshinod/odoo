# -*- coding: utf-8 -*-
# This module and its content is copyright of Technaureus Info Solutions Pvt. Ltd.
# - © Technaureus Info Solutions Pvt. Ltd 2025. All rights reserved.

{
    "name": "Sale Order Approval",
    "version": '18.0',
    "category": 'Sale',
    "summary": "Requires approval for sales orders before confirmation.",
    "description": """
This application allows to configure approvals for validating an sale order.
 """,
    "sequence": 1,
    "author": "Technaureus Info Solutions Pvt. Ltd.",
    "website": "http://www.technaureus.com/",
    'price': 12,
    'currency': 'EUR',
    'license': 'Other proprietary',
    "depends": ['sale_management'],
    "data": [
        # security
        'security/ir.model.access.csv',
        # data
        'data/mail_template.xml',
        'data/mail_activity_type.xml',
        #report
        'report/ir_actions_report_templates.xml',
        # views
        'views/sale_order_approvals_views.xml',
        'views/res_config_settings_views.xml',
        'views/sale_order_views.xml',
    ],
    'images': ['images/main_screenshot.png'],
    "installable": True,
    "application": True,
    "auto_install": False,
}
