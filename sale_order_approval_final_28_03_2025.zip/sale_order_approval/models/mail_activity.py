from odoo import fields, models, _

class MailActivity(models.Model):
    """
        Extends the 'mail.activity' model to handle sale order approval activities.
    """

    _inherit = "mail.activity"

    def _action_done(self, feedback=False, attachment_ids=None):
        """Mark the activity as done and validate approvers only if it's an approval activity."""

        sale_orders = self.env['sale.order']
        approval_activity_type = self.env.ref('sale_order_approval.mail_activity_data_sale_approval', raise_if_not_found=False)

        for activity in self.filtered(lambda a: a.res_model == 'sale.order' and a.res_id):
            if activity.activity_type_id != approval_activity_type:
                continue  # Skip non-approval activities

            sale_order = self.env['sale.order'].browse(activity.res_id)
            approver = sale_order.approver_validate_ids.filtered(lambda a: a.approver_id.id == self.env.user.id)

            if approver and not approver.is_validated:
                approver.write({'is_validated': True,
                                'approval_date': fields.Datetime.now() })

            if not sale_order.approver_validate_ids.filtered(lambda a: not a.is_validated):
                sale_orders |= sale_order

        if sale_orders:
            sale_orders.with_context(prevent_recursion=True).button_approve()

        return super()._action_done(feedback=feedback, attachment_ids=attachment_ids)
