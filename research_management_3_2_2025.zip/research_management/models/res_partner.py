# To add a new field odoo contacts

from odoo import api,models, fields

class ResPartner(models.Model):
    """
        Extends the res.partner model to include a custom field 'is_researcher'.

        This field is used to indicate whether a partner is a researcher.
        It defaults to True, and can be updated based on the partner's role
        within the system. This customization is particularly useful in
        modules related to research management or academic projects.
    """
    _inherit = 'res.partner'

    is_researcher = fields.Boolean(
        string="Is Researcher",
        default=lambda self: self.env.context.get('default_is_researcher', False)
    )

    @api.model
    def create(self, vals):
        # Ensure 'is_researcher' is set to True if not already defined
        if vals.get('is_researcher') is None:  # Check for 'is_researcher' field
            vals['is_researcher'] = True  # Set 'is_researcher' to True by default
        return super(ResPartner, self).create(vals)