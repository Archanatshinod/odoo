{
    'name': 'Research Management',
    'version': '1.3',
    'sequence': 1,  # This defines the loading order of the module
    'summary': 'For managing research projects, including tracking progress, and report generation.',
    'description': 'This is a web application using Odoo to efficiently manage research projects',
    'license': 'LGPL-3',
    'depends': ['base', 'mail', 'contacts','account'],


    'data': [
            # Security
            'security/security.xml',
            'security/ir.model.access.csv',

            #data
            'data/cron.xml',

            # Report
            'report/research_project_report_template.xml',
            'report/research_project_report_views.xml',
            #wizard
            'wizard/research_reporting_views.xml',
            # Views
            'views/research_project_views.xml',
            'views/res_partner_views.xml',

            # Menus
            'views/research_management_menu.xml',
    ],
    'installable': True,
    'application': True,
}
