from odoo import models, fields

class ResearchExpenses(models.Model):
    """
        Represents expenses associated with research projects.

        This model is used to track and manage the expenses incurred
        for specific research projects. Each expense is linked to a project
        and includes details such as a description and price.
    """
    _name = 'research.expenses'
    _description = 'Research Project Expenses'

    project_id = fields.Many2one(
        'research.project',
        string="Project",
        required=True,  # Ensures every expense has an associated project
    )
    description = fields.Char(string="Description", required=True)
    price = fields.Float(string="Price", required=True)

