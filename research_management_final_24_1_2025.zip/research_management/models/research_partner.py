# To add a new field odoo contacts

from odoo import models, fields

class ResPartner(models.Model):
    """
        Extends the res.partner model to include a custom field 'is_researcher'.

        This field is used to indicate whether a partner is a researcher.
        It defaults to True, and can be updated based on the partner's role
        within the system. This customization is particularly useful in
        modules related to research management or academic projects.
    """
    _inherit = 'res.partner'

    is_researcher = fields.Boolean(string="Is Researcher",default=True)

