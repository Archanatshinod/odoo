import base64
from importlib.resources import _
from datetime import datetime, timedelta
from odoo import  api,fields, models
from odoo.exceptions import AccessError, UserError, ValidationError


class ResearchProject(models.Model):
    """
        The `ResearchProject` model is used to track information related to a research project. It includes
        fields such as the project name, start date, end date, project summary, and the researchers involved.
        The model also manages the status of the project, allowing transitions between 'Draft', 'In Progress',
        'Completed', and 'Cancelled' states. It includes methods to compute the project's duration, validate
        the dates, and post notifications when the project status changes.
    """
    _name = "research.project"
    _inherit = ['mail.thread', 'mail.activity.mixin',]
    _description = "Research Project Model"

    # Fields
    name = fields.Char(string="Project Name", required=True, tracking=True)
    start_date = fields.Date(default=lambda self: fields.Date.today(),required=True)
    end_date = fields.Date(string="End Date",required=True)
    duration = fields.Integer(compute="_compute_duration", store=True, string="Duration (in days)", default=30)
    researcher_ids = fields.Many2many(
        'res.partner',
        string="Researchers",
        domain=[('is_researcher', '=', True)]
    )

    # researcher_ids = fields.Many2many(
    #     "research.researcher",
    #     "research_project_researcher_rel",
    #     "project_id",
    #     "researcher_id",
    #     string="Researchers",
    #     tracking=True,required=True
    #
    # )

    project_summary = fields.Text(
        string="Project Summary",
        help="Provide a brief description of the project’s goals, milestones, and outcomes.",
        required=True
    )
    status = fields.Selection(
        [('draft', 'Draft'), ('in_progress', 'In Progress'), ('completed', 'Completed'), ('cancelled', 'Cancelled')],
        default='draft',
        string="Status",
        tracking=True,
    )

    attachment_ids = fields.One2many('ir.attachment', 'res_id', domain=[('res_model', '=', 'research.project')],
                                     string="Attachments")
    document_count = fields.Integer(
        string='Document Count',
        compute='_compute_document_count',
        store=True
    )
    expenses = fields.One2many(
        'research.expenses',
        'project_id',
        string="Expenses"
    )
    # Relation to account.move (multiple invoices for a project)
    invoice_ids = fields.Many2many('account.move', 'research_project_invoice_rel', 'project_id', 'invoice_id', string="Invoices")

    # Field to compute the number of invoices
    invoice_count = fields.Integer(string="Invoice Count", compute='_compute_invoice_count')

    # To compute the no.of documents attached  to the project
    @api.depends('attachment_ids')
    def _compute_document_count(self):
        """
        Computes the number of documents attached to the project.
        This method is triggered when the 'attachment_ids' field is updated.
        It calculates the length of the 'attachment_ids' and stores it in the 'document_count' field,
        providing the total number of attachments associated with the project.
        """
        for record in self:
            record.document_count = len(record.attachment_ids)


    # Compute duration
    @api.depends("start_date", "end_date")
    def _compute_duration(self):
        """
            The _compute_duration method computes the duration between the start and end dates for a research record.
            This function is triggered when either the `start_date` or `end_date` fields are modified.
            It calculates the number of days between the `start_date` and `end_date` and stores the result
            in the `duration` field. If either of the dates is missing, the function assigns a default
            duration of 30 days.
            The computed duration is stored in the `duration` field.
        """

        for research in self:
            if research.start_date and research.end_date:
                delta = research.end_date - research.start_date
                research.duration = delta.days
            else:
                research.duration = 30  # Default duration set to 30 days if not computed

    # Validation for end_date
    @api.constrains("start_date", "end_date")
    def _check_dates(self):
        """
            The _check_dates method validates the relationship between the start and end dates for a research record.
            This function is triggered when either the `start_date` or `end_date` fields are modified.
            It checks that the `end_date` is not earlier than the `start_date`. If the `end_date` is found
            to be earlier than the `start_date`, a `ValidationError` is raised with an appropriate error message.
        """

        for research in self:
            if research.start_date and research.end_date and research.end_date < research.start_date:
                raise ValidationError("The end date cannot be earlier than the start date.")


    # methods for status updates post messages
    def action_in_progress(self):
        """
           action_in_progress method updates the project status to 'In Progress' and posts a notification message.
           This function sets the `status` field of the current project to 'in_progress'. Additionally,
           it posts a message in the project's message wall notifying that the project status has been updated
           to 'In Progress'. The message is posted with the appropriate note subtype.
        """
        self.status = 'in_progress'
        self.message_post(
            body="Project status updated to In Progress.",
            subtype_id=self.env.ref('mail.mt_note').id,
        )

    def action_completed(self):
        """
          action_completed method updates the project status to 'Completed' and posts a notification message.
          This function sets the `status` field of the current project to 'completed'. Additionally,
          it posts a message in the project's message wall notifying that the project status has been updated
          to 'Completed'. The message is posted with the appropriate note subtype.
        """
        self.status = 'completed'
        self.message_post(
            body="Project status updated to Completed.",
            subtype_id=self.env.ref('mail.mt_note').id,
        )

    def action_cancel(self):
        """
             action_cancel method updates the project status to 'Cancelled' and posts a notification message.
             This function sets the `status` field of the current project to 'cancelled'. Additionally,
             it posts a message in the project's message wall notifying that the project status has been updated
             to 'Cancelled'. The message is posted with the appropriate note subtype.
        """

        self.status = 'cancelled'
        self.message_post(
            body="Project status updated to Cancelled.",
            subtype_id=self.env.ref('mail.mt_note').id,
        )


    def action_open_documents(self):
        """Open the list view of attached documents."""
        if not self.env.user.has_group('research_management.group_research_management_admin'):
            raise AccessError(_("You do not have access to this functionality."))

        self.ensure_one()
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Documents',
            'res_model': 'ir.attachment',
            'view_mode': 'list,form',
            'domain': [('res_model', '=', self._name), ('res_id', '=', self.id)],
            'context': {'default_res_model': self._name, 'default_res_id': self.id},
        }
        return action

    # method for activity triggered when a project’s end_date is approaching
    def _notify_end_date_approaching(self):
        """
        Automatically creates a 'To-Do' activity for researchers when the end date is within 7 days
        of the start date.
        """
        for record in self:
            if not record.start_date or not record.end_date:
                raise UserError("Both the project's start date and end date must be set.")

            # Check if the end date is within 7 days of the start date
            if record.end_date <= record.start_date + timedelta(days=7):
                activity_type = self.env['mail.activity.type'].search([('name', '=', 'To-Do')], limit=1)
                if not activity_type:
                    raise UserError("Activity Type 'To-Do' not found. Please configure it.")

                for researcher in record.researcher_ids:
                    if researcher.email:
                        self.env['mail.activity'].create({
                            'activity_type_id': activity_type.id,
                            'res_id': record.id,
                            'res_model_id': self.env['ir.model']._get('research.project').id,
                            'summary': f"Reminder for {researcher.name}",
                            'note': f"The project's end date '{record.end_date}' is approaching. Please review the details.",
                            'user_id': self.env.user.id,
                            'date_deadline': record.end_date,
                        })

    @api.model_create_multi
    def create(self, vals):
        """
        Override create to automatically create 'To-Do' activities based on start and end dates.
        """
        record = super(ResearchProject, self).create(vals)
        record._notify_end_date_approaching()  # Trigger activity creation
        return record

    def write(self, vals):
        """
        Override write to automatically create 'To-Do' activities if start_date or end_date changes.
        """
        res = super(ResearchProject, self).write(vals)

        # Trigger the activity creation logic if dates are modified
        if 'start_date' in vals or 'end_date' in vals:
            self._notify_end_date_approaching()

        return res

    def send_email_with_pdf_attach(self):
        """
        Generates a PDF report for the research project and prepares an email with the report as an attachment.
        Opens the email composer for manual editing before sending.
        """

        self.ensure_one()

        # Check if the current user belongs to the research_management_admin group
        if not self.env.user.has_group('research_management.group_research_management_admin'):
            raise AccessError("You do not have the necessary permissions to perform this action.")

        # Get the report action by its reference
        report_action = self.env.ref('research_management.action_report_research_project')
        if not report_action:
            raise UserError("The report action is missing. Please check the report configuration.")

        # Generate the PDF report
        pdf_content, _ = self.env["ir.actions.report"].sudo()._render_qweb_pdf(
            report_action.report_name,
            res_ids=[self.id]
        )

        # Encode the PDF content to base64
        attachment_data = base64.b64encode(pdf_content)

        # Create the attachment
        attachment = self.env['ir.attachment'].sudo().create({
            'name': f"Research_Project_{self.name}.pdf",
            'type': 'binary',
            'datas': attachment_data,
            'mimetype': 'application/pdf',
            'res_model': 'research.project',
            'res_id': self.id,
        })

        # Get researcher emails
        researcher_emails = self.researcher_ids.mapped('email')
        if not researcher_emails:
            raise UserError("No email addresses found for the researchers.")

        # Fetch existing partners for the given emails
        existing_partners = self.env['res.partner'].sudo().search([('email', 'in', researcher_emails)])
        existing_emails = existing_partners.mapped('email')

        # Determine emails that do not have partners yet
        missing_emails = list(set(researcher_emails) - set(existing_emails))

        # Batch create missing partners
        new_partners = self.env['res.partner'].sudo().create([
            {
                'name': researcher.name or 'Unknown Researcher',
                'email': researcher.email
            }
            for researcher in self.researcher_ids
            if researcher.email in missing_emails
        ])

        # Combine existing and newly created partner IDs
        partner_ids = (existing_partners + new_partners).ids

        # Email content
        email_content = f"""
            <p>Dear Researchers,</p>
            <p>Please find attached the Research Project Report for <strong>{self.name}</strong>.</p>
            <p><strong>Project Summary:</strong></p>
            <p>{self.project_summary}</p>
            <p>Best regards,<br/>The Research Team</p>
        """

        # Return email composer action
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'view_type': 'form',
            'res_model': 'mail.compose.message',
            'views': [(self.env.ref('mail.email_compose_message_wizard_form').id, 'form')],
            'target': 'new',
            'context': {
                'default_model': 'research.project',
                'default_res_ids': [self.id],
                'default_use_template': False,
                'default_composition_mode': 'comment',
                'default_attachment_ids': [(4, attachment.id)],
                'default_partner_ids': [(6, 0, partner_ids)],
                'default_body': email_content,
                'mark_so_as_sent': True,
            }
        }

    # Method to create an invoice
    def create_expense_invoice(self):
        """
        Create an invoice for the project's expenses.
        """
        for project in self:
            if not project.expenses:
                raise ValidationError("The project must have at least one expense.")

            # Initialize invoice line items
            invoice_lines = []

            for expense in project.expenses:
                if not expense.description or not expense.price:
                    raise ValidationError(f"Expense {expense.id} is missing description or price.")

                # Create invoice line for each expense
                invoice_lines.append((0, 0, {
                    'name': expense.description,
                    'quantity': 1,
                    'price_unit': expense.price,
                }))

            partner_id = project.researcher_ids[0].id if project.researcher_ids else False

            # Create the invoice for the project
            invoice = self.env['account.move'].create({
                'move_type': 'in_invoice',
                'partner_id': partner_id,
                'invoice_date': fields.Date.today(),
                'line_ids': invoice_lines,
            })

            # Update the project with the created invoice ID
            project.invoice_ids = [(4, invoice.id)]

            # Return an action to open the invoice
            return {
                'type': 'ir.actions.act_window',
                'name': 'Invoice',
                'res_model': 'account.move',
                'view_mode': 'form',
                'res_id': invoice.id,
                'target': 'current',
            }
    @api.depends('invoice_ids')
    def _compute_invoice_count(self):
        """
        Update invoice count when invoice_ids changes
        """
        for project in self:
            project.invoice_count = len(project.invoice_ids)  # Count the number of invoices

    def action_view_invoice(self):
        """Create an action to view all invoices for the project"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Invoices',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [('id', 'in', [invoice.id for invoice in self.invoice_ids])],
        }