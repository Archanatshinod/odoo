{
    'name': 'research_management',
    'version': '1.3',
    'description': 'This is a web application using Odoo to efficiently manage research projects',
    'license': 'LGPL-3',
    'depends': ['base', 'mail', 'contacts','account','report_xlsx'],


    'data': [
            # Security
            'security/security.xml',
            'security/ir.model.access.csv',


            # Report
            'report/research_project_report_template.xml',
            'report/research_project_report_views.xml',
            #wizard
            'wizard/research_reporting_views.xml',
            # Views
            'views/research_project_views.xml',
            'views/research_researcher_views.xml',
            'views/research_partner_views.xml',

            # Menus
            'views/research_management_menu.xml',
    ],
    'installable': True,
    'application': True,
}
