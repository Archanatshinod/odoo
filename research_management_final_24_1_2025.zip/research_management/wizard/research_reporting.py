import base64
import io
from odoo import models, fields
from odoo.exceptions import UserError
from xlsxwriter.workbook import Workbook

class ResearchReporting(models.TransientModel):
    """
        A transient model for generating research project reports.

        This wizard allows users to generate reports for research projects within a specified date range.
        Users can choose between two report formats: PDF and Excel.
    """
    _name = 'research.reporting'
    _description = 'Research Reporting'

    start_date = fields.Date('Start Date', required=True)
    end_date = fields.Date('End Date', required=True)
    report_format = fields.Selection([('pdf', 'PDF'), ('excel', 'Excel')], string='Report Format', required=True)

    def validate_dates(self):
        """Ensure start date is before or equal to end date."""
        if self.start_date > self.end_date:
            raise UserError("Start date cannot be after End date.")

    def generate_report(self):
        """Generate the report based on the date range and format."""
        self.validate_dates()

        # Fetching the research projects within the date range
        research_projects = self.env['research.project'].search([
            ('start_date', '>=', self.start_date),
            ('start_date', '<=', self.end_date)
        ])

        # Generate the report based on the selected format
        if self.report_format == 'pdf':
            return self.generate_pdf_report(research_projects)
        elif self.report_format == 'excel':
            return self.generate_excel_report(research_projects)

    #for PDF report
    def generate_pdf_report(self, research_projects):
        """Generate PDF report logic."""
        if not research_projects:
            raise UserError("No research projects found within the selected date range.")

            # Generate the PDF content
        report_service = self.env["ir.actions.report"]
        report_name = "research_management.report_research_project"

        pdf_content, _ = report_service._render_qweb_pdf(
            report_name, res_ids=research_projects.ids
        )

        pdf_filename = "Research_Project_Report.pdf"

        # Create an attachment for the generated PDF
        attachment = self.env['ir.attachment'].create({
            'name': pdf_filename,
            'type': 'binary',
            'datas': base64.b64encode(pdf_content),
            'mimetype': 'application/pdf',
            'res_model': 'research.reporting',  # Model linked to the wizard
            'res_id': self.id,
        })

        # Return a URL pointing to the generated attachment
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'self',
        }

    # for Excel report
    def generate_excel_report(self, research_projects):
        """Generate Excel report logic."""
        if not research_projects:
            raise UserError("No research projects found within the selected date range.")

        # Create an in-memory Excel file using xlsxwriter
        output = io.BytesIO()
        workbook = Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet("Research Projects")

        # Define the header
        headers = ["Project Name", "Start Date", "End Date", "Duration", "Status"]
        for col, header in enumerate(headers):
            sheet.write(0, col, header)

        # Populate data with the research projects
        for row, project in enumerate(research_projects, start=1):
            sheet.write(row, 0, project.name)
            sheet.write(row, 1, str(project.start_date))
            sheet.write(row, 2, str(project.end_date))
            sheet.write(row, 3, project.duration)
            sheet.write(row, 4, project.status)

        # Close the workbook to finalize the content
        workbook.close()

        # Get the file content and encode to base64
        output.seek(0)  # Go back to the start of the BytesIO object
        file_data = base64.b64encode(output.read()).decode('utf-8')

        # Create an attachment for the generated Excel file
        excel_filename = "Research_Project_Report.xlsx"
        attachment = self.env['ir.attachment'].create({
            'name': excel_filename,
            'type': 'binary',
            'datas': file_data,
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'res_model': 'research.reporting',
            'res_id': self.id,
        })

        # Return a URL pointing to the generated attachment for download
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'self',
        }