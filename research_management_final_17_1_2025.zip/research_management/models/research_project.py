import base64
from importlib.resources import _
from datetime import datetime, timedelta
from odoo import  api,fields, models
from odoo.exceptions import ValidationError, UserError, AccessError


class ResearchProject(models.Model):
    """
        The `ResearchProject` model is used to track information related to a research project. It includes
        fields such as the project name, start date, end date, project summary, and the researchers involved.
        The model also manages the status of the project, allowing transitions between 'Draft', 'In Progress',
        'Completed', and 'Cancelled' states. It includes methods to compute the project's duration, validate
        the dates, and post notifications when the project status changes.
    """
    _name = "research.project"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Research Project Model"

    # Fields
    name = fields.Char(string="Project Name", required=True, tracking=True)
    start_date = fields.Date(default=lambda self: fields.Date.today(),required=True)
    end_date = fields.Date(string="End Date",required=True)
    duration = fields.Integer(compute="_compute_duration", store=True, string="Duration (in days)", default=30)
    researcher_ids = fields.Many2many(
        "research.researcher",
        "research_project_researcher_rel",
        "project_id",
        "researcher_id",
        string="Researchers",
        tracking=True,required=True

    )
    # color = fields.Char("Color", default="yellow")  # New field
    project_summary = fields.Text(
        string="Project Summary",
        help="Provide a brief description of the project’s goals, milestones, and outcomes.",
        required=True
    )
    status = fields.Selection(
        [('draft', 'Draft'), ('in_progress', 'In Progress'), ('completed', 'Completed'), ('cancelled', 'Cancelled')],
        default='draft',
        string="Status",
        tracking=True,
    )

    attachment_ids = fields.One2many('ir.attachment', 'res_id', domain=[('res_model', '=', 'research.project')],
                                     string="Attachments")
    document_count = fields.Integer(
        string='Document Count',
        compute='_compute_document_count',
        store=True
    )

    # To compute the no.of documents attached  to the project
    @api.depends('attachment_ids')
    def _compute_document_count(self):
        """
        Computes the number of documents attached to the project.
        This method is triggered when the 'attachment_ids' field is updated.
        It calculates the length of the 'attachment_ids' and stores it in the 'document_count' field,
        providing the total number of attachments associated with the project.
        """
        for record in self:
            record.document_count = len(record.attachment_ids)


    # Compute duration
    @api.depends("start_date", "end_date")
    def _compute_duration(self):
        """
            The _compute_duration method computes the duration between the start and end dates for a research record.
            This function is triggered when either the `start_date` or `end_date` fields are modified.
            It calculates the number of days between the `start_date` and `end_date` and stores the result
            in the `duration` field. If either of the dates is missing, the function assigns a default
            duration of 30 days.
            The computed duration is stored in the `duration` field.
        """

        for research in self:
            if research.start_date and research.end_date:
                delta = research.end_date - research.start_date
                research.duration = delta.days
            else:
                research.duration = 30  # Default duration set to 30 days if not computed

    # Validation for end_date
    @api.constrains("start_date", "end_date")
    def _check_dates(self):
        """
            The _check_dates method validates the relationship between the start and end dates for a research record.
            This function is triggered when either the `start_date` or `end_date` fields are modified.
            It checks that the `end_date` is not earlier than the `start_date`. If the `end_date` is found
            to be earlier than the `start_date`, a `ValidationError` is raised with an appropriate error message.
        """

        for research in self:
            if research.start_date and research.end_date and research.end_date < research.start_date:
                raise ValidationError("The end date cannot be earlier than the start date.")


    # methods for status updates post messages
    def action_in_progress(self):
        """
           action_in_progress method updates the project status to 'In Progress' and posts a notification message.
           This function sets the `status` field of the current project to 'in_progress'. Additionally,
           it posts a message in the project's message wall notifying that the project status has been updated
           to 'In Progress'. The message is posted with the appropriate note subtype.
        """
        self.status = 'in_progress'
        self.message_post(
            body="Project status updated to In Progress.",
            subtype_id=self.env.ref('mail.mt_note').id,
        )

    def action_completed(self):
        """
          action_completed method updates the project status to 'Completed' and posts a notification message.
          This function sets the `status` field of the current project to 'completed'. Additionally,
          it posts a message in the project's message wall notifying that the project status has been updated
          to 'Completed'. The message is posted with the appropriate note subtype.
        """
        self.status = 'completed'
        self.message_post(
            body="Project status updated to Completed.",
            subtype_id=self.env.ref('mail.mt_note').id,
        )

    def action_cancel(self):
        """
             action_cancel method updates the project status to 'Cancelled' and posts a notification message.
             This function sets the `status` field of the current project to 'cancelled'. Additionally,
             it posts a message in the project's message wall notifying that the project status has been updated
             to 'Cancelled'. The message is posted with the appropriate note subtype.
        """

        self.status = 'cancelled'
        self.message_post(
            body="Project status updated to Cancelled.",
            subtype_id=self.env.ref('mail.mt_note').id,
        )


    def action_open_documents(self):
        """Open the list view of attached documents."""
        if not self.env.user.has_group('research_management.group_research_management_admin'):
            raise AccessError(_("You do not have access to this functionality."))

        self.ensure_one()
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Documents',
            'res_model': 'ir.attachment',
            'view_mode': 'list,form',
            'domain': [('res_model', '=', self._name), ('res_id', '=', self.id)],
            'context': {'default_res_model': self._name, 'default_res_id': self.id},
        }
        return action

    # method for activity triggered when a project’s end_date is approaching
    def _notify_end_date_approaching(self):
        """
        Notifies researchers when a project's end date is approaching.
        This method checks if a project's end date is within 7 days from the current date and
        creates a 'To-Do' activity for each researcher associated with the project.
        If the end date is not set or the activity type 'To-Do' is not found, it raises an error.
        """
        for researcher in self.researcher_ids:
            if researcher.email:
                if not self.end_date:
                    raise UserError(
                        "The project's end date is not set. Please define it before creating activities.")

                # Check if the end_date is within 7 days from the current date
                if self.end_date <= fields.Date.today() + timedelta(days=7):
                    # Create a simple activity
                    activity_type = self.env['mail.activity.type'].search([('name', '=', 'To-Do')], limit=1)
                    if not activity_type:
                        raise UserError("Activity Type 'To Do' not found. Please configure it.")

                    self.env['mail.activity'].create({
                        'activity_type_id': activity_type.id,
                        'res_id': self.id,
                        'res_model_id': self.env['ir.model']._get('research.project').id,
                        'summary': f"Reminder for {researcher.name}",
                        'note': f"The end date for the project '{self.name}' is approaching. Please review the details.",
                        'user_id': self.env.user.id,
                        'date_deadline': self.end_date,
                    })

    # Methods for triggering notification based on end_date on creation of project or change in project
    @api.model
    def create(self, vals):
        """
        Override create to trigger the notification method once after the record is created.
        """
        record = super(ResearchProject, self).create(vals)
        record._notify_end_date_approaching()  # Call method after creation
        return record

    def write(self, vals):
        """
        Override write to trigger the notification method if end_date is reduced to 7 days or less.
        """
        if 'end_date' in vals:
            # If the end_date is updated and reduced to 7 days or less, trigger the notification
            new_end_date = vals.get('end_date')
            if new_end_date and fields.Date.from_string(new_end_date) <= fields.Date.today() + timedelta(days=7):
                self._notify_end_date_approaching()

        return super(ResearchProject, self).write(vals)


    def send_email_with_pdf_attach(self):
        """
        Generates a PDF report for the research project and sends it via email to each researcher.
        This method retrieves the report associated with the research project, generates the PDF,
        attaches it to an email, and sends the email to all researchers associated with the project.
        It also posts a message in the project's chatter to notify that the email has been sent.
        """
        try:
            # Get the report action by its reference
            report_action = self.env.ref('research_management.action_report_research_project')

            if not report_action:
                raise UserError("The report action is missing. Please check the report configuration.")

            # Fetch the report using the report action's report name
            pdf_content, _ = self.env["ir.actions.report"].sudo()._render_qweb_pdf(
                report_action.report_name,
                res_ids=self.ids
            )

            # Encode the PDF content to base64
            attachment_data = base64.b64encode(pdf_content)

            # Create the attachment in the system
            attachment = self.env['ir.attachment'].sudo().create({
                'name': f"Research_Project_{self.name}.pdf",
                'type': 'binary',
                'datas': attachment_data,
                'mimetype': 'application/pdf',
                'res_model': 'research.project',
                'res_id': self.id,
            })

            # Loop through each researcher and send individual emails
            for researcher in self.researcher_ids:
                email_values = {
                    'subject': f"Research Project Report: {self.name}",
                    'body_html': f"""
                        <p>Dear {researcher.name},</p>
                        <p>Please find attached the Research Project Report for <strong>{self.name}</strong>.</p>
                        <p><strong>Project Summary:</strong></p>
                        <p>{self.project_summary}</p>
                        <p>Best regards,<br/>Your Company</p>
                    """,
                    'email_to': researcher.email,
                    'email_from': self.env.user.email,
                    'attachment_ids': [(4, attachment.id)],
                    'auto_delete': False,
                }

                draft_email = self.env['mail.mail'].create(email_values)

                # Post a message to the chatter of the project about the email sent
                self.message_post(
                    body=f"Email with Research Project Report '{self.name}' has been prepared for {researcher.name}. \n Project Summary:{self.project_summary}",
                    subject=f"Email Sent: {self.name}",
                    message_type='notification',
                    attachment_ids=[attachment.id],
                )
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'mail.mail',
                'res_id': draft_email.id,
                'view_mode': 'form',
                'target': 'new',
            }

        except Exception as e:
            raise UserError(f"Error generating or previewing the report: {str(e)}")
