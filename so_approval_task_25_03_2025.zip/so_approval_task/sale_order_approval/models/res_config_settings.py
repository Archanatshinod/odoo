# -*- coding: utf-8 -*-
# This module and its content is copyright of Technaureus Info Solutions Pvt. Ltd.
# - © Technaureus Info Solutions Pvt. Ltd 2025. All rights reserved.

from odoo import fields,models

class ResConfigSettings(models.TransientModel):
    """ Inheriting ResConfigSettings model"""
    _inherit = 'res.config.settings'

    approvals = fields.Boolean(config_parameter='sale_order_approval.approvals',
                               help="Configuration approvals for the sale order")
