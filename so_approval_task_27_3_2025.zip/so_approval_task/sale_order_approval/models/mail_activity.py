from odoo import models

class MailActivity(models.Model):
    _inherit = "mail.activity"

    def _action_done(self, feedback=False, attachment_ids=None):
        """Mark the activity as done and validate approvers if required."""

        sale_orders = self.env['sale.order']

        for activity in self.filtered(lambda a: a.res_model == 'sale.order' and a.res_id):
            sale_order = self.env['sale.order'].browse(activity.res_id)
            approver = sale_order.approver_validate_ids.filtered(lambda a: a.approver_id.id == self.env.user.id)

            if approver and not approver.is_validated:
                approver.write({'is_validated': True})

            if not sale_order.approver_validate_ids.filtered(lambda a: not a.is_validated):
                sale_orders |= sale_order

        if sale_orders:
            sale_orders.with_context(prevent_recursion=True).button_approve()

        return super()._action_done(feedback=feedback, attachment_ids=attachment_ids)
