# -*- coding: utf-8 -*-
# This module and its content is copyright of Technaureus Info Solutions Pvt. Ltd.
# - © Technaureus Info Solutions Pvt. Ltd 2025. All rights reserved.

from odoo import api,fields,models

class ResConfigSettings(models.TransientModel):
    """ Inheriting ResConfigSettings model"""
    _inherit = 'res.config.settings'

    approvals = fields.Boolean(config_parameter='sale_order_approval.approvals',
                               help="Configuration approvals for the sale order")
    pdf=fields.Boolean(string='PDF',config_parameter='sale_order_approval.pdf',
                               help="To show Approvals on PDF report")

    @api.onchange('approvals')
    def _onchange_approvals(self):
        """Disable the PDF field when approvals is turned off"""
        if not self.approvals:
            self.pdf = False