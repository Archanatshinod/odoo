# -*- coding: utf-8 -*-
# This module and its content is copyright of Technaureus Info Solutions Pvt. Ltd.
# - © Technaureus Info Solutions Pvt. Ltd 2025. All rights reserved.

from . import res_config_settings
from . import sale_order_approvals
from . import sale_order
from . import mail_activity
